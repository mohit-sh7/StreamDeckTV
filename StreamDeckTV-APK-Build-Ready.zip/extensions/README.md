# StreamDeck TV Extension SDK (v1)

StreamDeck TV extensions use a small declarative JSON manifest so new integrations can be registered without modifying the launcher’s core UI. The launcher can validate this manifest, present extension metadata, and open an HTTPS URL or launch an installed app package.

## Supported entry types

### Website shortcut
```json
{
  "schemaVersion": 1,
  "id": "dev.example.news",
  "name": "News",
  "version": "1.0.0",
  "description": "TV-friendly news page",
  "developer": "Example Dev",
  "entry": { "type": "url", "url": "https://example.com/tv" },
  "capabilities": ["launcher.shortcut"],
  "permissions": [],
  "minLauncherVersion": "0.1.0"
}
```

### Installed Android app shortcut
```json
{
  "schemaVersion": 1,
  "id": "dev.example.myapp",
  "name": "My App",
  "version": "1.0.0",
  "description": "Open the installed TV app",
  "developer": "Example Dev",
  "entry": { "type": "android-app", "packageName": "dev.example.myapp" },
  "capabilities": ["launcher.shortcut"],
  "permissions": [],
  "minLauncherVersion": "0.1.0"
}
```

## Design constraints

- Keep extensions declarative in v1; no arbitrary code execution, dynamic Kotlin loading, reflection plugins, or injected JavaScript.
- Only HTTPS web URLs are permitted.
- Extensions must declare capabilities and permissions. Unknown permissions are rejected.
- Package launch should use Android's official launch intents.
- Any future privileged capability needs a versioned API, explicit user consent, review, and sandboxing before implementation.
- Remote catalog entries are metadata only. The app must not download or execute extension code.
