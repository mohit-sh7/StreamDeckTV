import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const catalogPath = path.join(here, "catalog.json");
const port = Number(process.env.PORT || 3000);

function json(res, status, body) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, OPTIONS",
    "access-control-allow-headers": "content-type",
    "cache-control": "public, max-age=60"
  });
  res.end(JSON.stringify(body, null, 2));
}

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") return json(res, 204, {});
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
  if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
    return json(res, 200, { service: "StreamDeck TV Extension Catalog", status: "ok", version: "1.0.0", endpoints: ["/api/extensions", "/api/extensions/:id", "/health"] });
  }
  if (req.method === "GET" && url.pathname === "/api/extensions") {
    const data = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
    return json(res, 200, data);
  }
  if (req.method === "GET" && url.pathname.startsWith("/api/extensions/")) {
    const id = decodeURIComponent(url.pathname.slice("/api/extensions/".length));
    const data = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
    const found = data.extensions.find(e => e.id === id);
    return found ? json(res, 200, found) : json(res, 404, { error: "Extension not found", id });
  }
  return json(res, 404, { error: "Not found" });
});

server.listen(port, "0.0.0.0", () => console.log(`StreamDeck Extension Catalog listening on ${port}`));
