import catalog from "../../catalog.json" with { type: "json" };
export default function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  const item = catalog.extensions.find((extension) => extension.id === req.query.id);
  if (!item) return res.status(404).json({ error: "Extension not found" });
  res.setHeader("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
  return res.status(200).json(item);
}
