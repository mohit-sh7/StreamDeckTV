# StreamDeck TV (prototype)

A native Kotlin + Jetpack Compose TV launcher prototype tailored for Chromecast with Google TV (2 GB RAM).

## Features
- Remote-first dark launcher UI
- Pinned streaming service shortcuts (launches installed official apps when their package/launch activity is available)
- Apps screen
- On-demand WebView browser screen
- Address/search dialog, Back/Forward/Reload controls
- No backend, accounts, analytics, or background service

## Open and build
1. Install Android Studio (JDK 17).
2. Open this folder as a project.
3. Let Gradle sync.
4. Connect Chromecast with Google TV using ADB over the same network, or use an Android TV emulator.
5. Enable Developer options and Network debugging on the Chromecast, pair/connect using the IP and pairing code shown on the TV.
6. Choose the `app` run configuration and install.

## Important prototype notes
- This source has not been built or tested on the target Chromecast in this environment.
- Package IDs for streaming apps can vary by region/version. The app tries common candidates; validate installed package IDs on your device.
- Streaming playback is delegated to official apps. The launcher does not bypass DRM or guarantee a service's resolution/availability.
- WebView is created on the browser screen and destroyed when leaving it to reduce memory pressure.
- This is a starter project, not yet a production launcher replacement. The browser address dialog uses Android's input method, which may not be ideal on every TV. A dedicated D-pad on-screen keyboard and bookmarks/history are planned next.

## Extension developer experience
- `extensions/extension.sample.json` documents the v1 declarative manifest.
- `extensions/README.md` includes website and Android-app shortcut contracts and safety constraints.
- `extension-catalog/` is a standalone Node API and static developer hub intended for Railway and Vercel.
- Catalog API returns metadata only; no arbitrary extension code is downloaded or executed.

## Deploy the catalog
- Railway: deploy `extension-catalog/` as the root directory; build uses Node/Nixpacks and `npm start`, honoring `PORT`.
- Vercel: import the `extension-catalog/` directory as a project; it contains `index.html`, `/api/extensions`, and `/api/extensions/:id` serverless handlers.
- Hosting the catalog does not host Netflix/Prime/Hotstar video and is not necessary for local launcher performance.


## Current extension UI
The launcher now includes an Extensions section with sample HTTPS shortcuts and a link to the developer guide. The first version intentionally supports declarative shortcut metadata, not arbitrary executable plugins.

## Deployment status
The extension catalog is deployment-ready but has not been published yet. Railway's deployment service reported that deployments are temporarily paused. Vercel project creation was denied because this integration lacks permission to the selected account/team scope; grant the Vercel integration access to the team and retry.

## Android phone and tablet support
The app now supports portrait and landscape orientation and includes a compact navigation rail for narrow screens. The manifest exposes both the Android TV launcher category and the standard Android launcher category, so it can be installed and opened on Android phones/tablets as well as Android TV. Streaming app availability and package names still depend on the device and the provider's installed app.

## Build an APK using GitHub Actions
This workspace does not have the Android SDK or Gradle installed, and network access is unavailable here, so an APK cannot be compiled inside this session. To build it in GitHub's Android build environment:
1. Push the project contents to a GitHub repository.
2. Open **Actions** and run **Build StreamDeck TV APK** (or push to `main`/`master`).
3. Download the `StreamDeckTV-debug-apk` artifact from the completed workflow.
4. Install `app-debug.apk` on your Android phone/TV. It is a debug build, not a Play Store release-signed APK.
