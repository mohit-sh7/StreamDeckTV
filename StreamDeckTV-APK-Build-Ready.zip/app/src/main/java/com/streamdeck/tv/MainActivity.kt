package com.streamdeck.tv

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.input.key.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.style.TextOverflow

private val Bg = Color(0xFF070B14)
private val Panel = Color(0xFF111A2A)
private val Panel2 = Color(0xFF17243A)
private val Accent = Color(0xFF48B8FF)
private val Muted = Color(0xFF9BAAC2)
private val White = Color(0xFFF4F7FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 11, 20)
        window.navigationBarColor = android.graphics.Color.rgb(7, 11, 20)
        setContent { StreamDeckApp() }
    }
}

private data class StreamApp(val name: String, val subtitle: String, val packageCandidates: List<String>, val tint: Color, val icon: ImageVector)

private val streamApps = listOf(
    StreamApp("Netflix", "Movies & series", listOf("com.netflix.ninja", "com.netflix.mediaclient"), Color(0xFFE50914), Icons.Default.PlayCircle),
    StreamApp("Prime Video", "Amazon streaming", listOf("com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient"), Color(0xFF159BE8), Icons.Default.PlayArrow),
    StreamApp("JioHotstar", "Sports & entertainment", listOf("in.startv.hotstar", "com.hotstar.android"), Color(0xFF4427E8), Icons.Default.Star),
    StreamApp("YouTube", "Videos", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), Color(0xFFFF3333), Icons.Default.SmartDisplay)
)

private enum class Screen { HOME, APPS, BROWSER, EXTENSIONS, SETTINGS }

@Composable
private fun StreamDeckApp() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var browserUrl by remember { mutableStateOf("https://www.google.com") }
    var showUrlDialog by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready when you are") }
    var refreshKey by remember { mutableIntStateOf(0) }

    BackHandler(enabled = screen != Screen.HOME) {
        screen = when (screen) {
            Screen.BROWSER -> Screen.HOME
            Screen.APPS, Screen.EXTENSIONS, Screen.SETTINGS -> Screen.HOME
            Screen.HOME -> Screen.HOME
        }
    }

    BoxWithConstraints(
        Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF0B1425), Bg, Color(0xFF070B12))))
    ) {
        val compact = maxWidth < 600.dp
        Row(Modifier.fillMaxSize()) {
        Column(
            Modifier.width(if (compact) 64.dp else 190.dp).fillMaxHeight().background(Color(0xCC080E1A)).padding(horizontal = if (compact) 6.dp else 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.padding(bottom = 18.dp)) {
                Icon(Icons.Default.PlayCircleFilled, null, tint = Accent, modifier = Modifier.size(30.dp))
                if (!compact) {
                    Column {
                        Text("StreamDeck", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("TV", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
            NavItem("Home", Icons.Default.Home, screen == Screen.HOME, compact) { screen = Screen.HOME }
            NavItem("Apps", Icons.Default.GridView, screen == Screen.APPS, compact) { screen = Screen.APPS }
            NavItem("Browser", Icons.Default.Language, screen == Screen.BROWSER, compact) { screen = Screen.BROWSER }
            NavItem("Extensions", Icons.Default.Extension, screen == Screen.EXTENSIONS, compact) { screen = Screen.EXTENSIONS }
            NavItem("Settings", Icons.Default.Settings, screen == Screen.SETTINGS, compact) { screen = Screen.SETTINGS }
            Spacer(Modifier.weight(1f))
            if (!compact) {
                Text("BUILT FOR THE BIG SCREEN", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                Text("v0.1 • Lightweight", color = Muted, fontSize = 11.sp)
            }
        }

        Column(Modifier.weight(1f).fillMaxHeight().padding(start = if (compact) 12.dp else 26.dp, end = if (compact) 12.dp else 28.dp, top = if (compact) 14.dp else 24.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when (screen) {
                            Screen.HOME -> "Your entertainment, one click away"
                            Screen.APPS -> "Your installed apps"
                            Screen.BROWSER -> "TV Browser"
                            Screen.EXTENSIONS -> "Extensions"
                            Screen.SETTINGS -> "Settings"
                        },
                        color = White, fontSize = if (compact) 20.sp else 27.sp, fontWeight = FontWeight.Bold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        when (screen) {
                            Screen.HOME -> if (compact) "Entertainment, one tap away" else "A fast, simple home for your TV"
                            Screen.APPS -> if (compact) "Open installed apps" else "Launch apps installed on this Chromecast"
                            Screen.BROWSER -> if (compact) "Browse the web" else "Browse the web with your remote"
                            Screen.EXTENSIONS -> "Add useful shortcuts"
                            Screen.SETTINGS -> "Simple controls. No clutter."
                        },
                        color = Muted, fontSize = if (compact) 12.sp else 14.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
                if (!compact) Surface(color = Panel, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0xFF27364C))) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Wifi, null, tint = Accent, modifier = Modifier.size(18.dp))
                        Text("STREAMDECK TV", color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(22.dp))

            when (screen) {
                Screen.HOME -> HomeScreen(
                    onLaunch = { app -> launchApp(context, app) },
                    onBrowser = { screen = Screen.BROWSER; refreshKey++ },
                    onApps = { screen = Screen.APPS },
                    onSetStatus = { status = it },
                    status = status
                )
                Screen.APPS -> AppsScreen(onLaunch = { launchApp(context, it) })
                Screen.BROWSER -> BrowserScreen(
                    initialUrl = browserUrl,
                    refreshKey = refreshKey,
                    onUrlChange = { browserUrl = it },
                    onEditUrl = { showUrlDialog = true }
                )
                Screen.EXTENSIONS -> ExtensionsScreen(
                    onOpen = { url ->
                        browserUrl = url
                        screen = Screen.BROWSER
                        refreshKey++
                    }
                )
                Screen.SETTINGS -> SettingsScreen()
            }
        }
        }
    }

    if (showUrlDialog) {
        UrlDialog(
            initial = browserUrl,
            onDismiss = { showUrlDialog = false },
            onGo = { value ->
                browserUrl = normalizeUrl(value)
                showUrlDialog = false
                screen = Screen.BROWSER
                refreshKey++
            }
        )
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, selected: Boolean, compact: Boolean = false, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(if (compact) 48.dp else 48.dp).onFocusChanged { focused = it.isFocused },
        shape = RoundedCornerShape(13.dp),
        color = when { focused -> Color(0xFFEAF5FF); selected -> Color(0xFF1A2B43); else -> Color.Transparent },
        border = if (focused) BorderStroke(2.dp, Accent) else BorderStroke(1.dp, if (selected) Color(0xFF294969) else Color.Transparent)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = if (compact) 0.dp else 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, null, tint = if (focused) Bg else if (selected) Accent else Muted, modifier = Modifier.size(20.dp))
            if (!compact) Text(label, color = if (focused) Bg else White, fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium, fontSize = 15.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    onLaunch: (StreamApp) -> Unit,
    onBrowser: () -> Unit,
    onApps: () -> Unit,
    onSetStatus: (String) -> Unit,
    status: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Panel,
            border = BorderStroke(1.dp, Color(0xFF263A55)),
            modifier = Modifier.fillMaxWidth()
        ) {
            BoxWithConstraints(Modifier.fillMaxWidth().padding(if (maxWidth < 520.dp) 16.dp else 24.dp)) {
                val narrow = maxWidth < 520.dp
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("LESS WAITING. MORE WATCHING.", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("Everything starts here.", color = White, fontSize = if (narrow) 22.sp else 30.sp, fontWeight = FontWeight.Bold)
                    Text("Your streaming apps and browser, organized for the screen you're using.", color = Muted, fontSize = if (narrow) 13.sp else 15.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        ActionButton("Browser", Icons.Default.Language, onBrowser, Modifier.weight(1f))
                        ActionButton("All Apps", Icons.Default.GridView, onApps, Modifier.weight(1f))
                    }
                }
                if (!narrow) Box(Modifier.padding(start = 12.dp).width(130.dp).height(110.dp).background(Color(0xFF142A44), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.LiveTv, null, tint = Accent, modifier = Modifier.size(64.dp))
                }
                }
            }
        }

        SectionHeader("Your streaming apps", "Select to open")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(end = 8.dp)) {
            items(streamApps) { app ->
                AppTile(app = app, onClick = { onLaunch(app); onSetStatus("Opening ${app.name}…") })
            }
        }
        Surface(color = Color(0x66121C2C), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0xFF26364C))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.Speed, null, tint = Accent)
                Text(status, color = Muted, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text("D-pad to navigate  •  OK to select", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AppsScreen(onLaunch: (StreamApp) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Pinned services", color = Muted, fontSize = 14.sp)
        streamApps.forEach { app -> AppRow(app, onLaunch) }
        Text("If a service is missing, install its official TV app from Google Play and reopen StreamDeck TV.", color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun AppRow(app: StreamApp, onLaunch: (StreamApp) -> Unit) {
    Surface(
        onClick = { onLaunch(app) },
        modifier = Modifier.fillMaxWidth().height(66.dp),
        shape = RoundedCornerShape(15.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color(0xFF27374D))
    ) {
        Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.size(42.dp).background(app.tint, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(app.icon, null, tint = Color.White, modifier = Modifier.size(25.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(app.name, color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(app.subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.PlayArrow, null, tint = Accent)
        }
    }
}

@Composable
private fun AppTile(app: StreamApp, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = Modifier.width(190.dp).height(118.dp).onFocusChanged { focused = it.isFocused },
        shape = RoundedCornerShape(18.dp),
        color = if (focused) Color(0xFFEEF7FF) else app.tint.copy(alpha = 0.95f),
        border = BorderStroke(if (focused) 3.dp else 1.dp, if (focused) Accent else Color(0x553B587A))
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(app.icon, null, tint = if (focused) Bg else Color.White, modifier = Modifier.size(29.dp))
            Column {
                Text(app.name, color = if (focused) Bg else Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(app.subtitle, color = if (focused) Bg.copy(alpha = .7f) else Color.White.copy(alpha = .8f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, hint: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(12.dp))
        Text(hint, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ActionButton(label: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = modifier.height(48.dp).onFocusChanged { focused = it.isFocused },
        shape = RoundedCornerShape(13.dp),
        color = if (focused) Color(0xFFEAF5FF) else Panel2,
        border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) Accent else Color(0xFF344761))
    ) {
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (focused) Bg else Accent, modifier = Modifier.size(19.dp))
            Text(label, color = if (focused) Bg else White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun BrowserScreen(
    initialUrl: String,
    refreshKey: Int,
    onUrlChange: (String) -> Unit,
    onEditUrl: () -> Unit
) {
    var webView by remember { mutableStateOf<WebView?>(null) }
    var currentUrl by remember { mutableStateOf(initialUrl) }
    var pageTitle by remember { mutableStateOf("Ready to browse") }

    DisposableEffect(Unit) {
        onDispose {
            webView?.stopLoading()
            webView?.destroy()
            webView = null
        }
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            ActionButton("Address / Search", Icons.Default.Search, onEditUrl, Modifier.width(210.dp))
            ActionButton("Back", Icons.Default.ArrowBack, { webView?.let { if (it.canGoBack()) it.goBack() } }, Modifier.width(95.dp))
            ActionButton("Forward", Icons.Default.ArrowForward, { webView?.let { if (it.canGoForward()) it.goForward() } }, Modifier.width(115.dp))
            ActionButton("Reload", Icons.Default.Refresh, { webView?.reload() }, Modifier.width(105.dp))
        }
        Text(pageTitle, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        AndroidView(
            modifier = Modifier.fillMaxSize().background(Color.White, RoundedCornerShape(12.dp)),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String) {
                            currentUrl = url
                            onUrlChange(url)
                            pageTitle = view.title ?: url
                        }
                    }
                    webChromeClient = WebChromeClient()
                    loadUrl(currentUrl)
                    webView = this
                }
            },
            update = { view ->
                if (view.url != initialUrl && initialUrl.isNotBlank()) {
                    view.loadUrl(initialUrl)
                }
            }
        )
    }
}

@Composable
private fun UrlDialog(initial: String, onDismiss: () -> Unit, onGo: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(.8f),
            shape = RoundedCornerShape(22.dp),
            color = Panel,
            border = BorderStroke(1.dp, Accent)
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Enter a website or search", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Website or search terms") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = White,
                        unfocusedTextColor = White,
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Muted,
                        focusedLabelColor = Accent,
                        unfocusedLabelColor = Muted,
                        cursorColor = Accent
                    )
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.align(Alignment.End)) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onGo(text) }) { Text("Go") }
                }
            }
        }
    }
}

private fun normalizeUrl(input: String): String {
    val value = input.trim()
    if (value.isEmpty()) return "https://www.google.com"
    if (value.contains(" ") || !value.contains(".")) {
        return "https://www.google.com/search?q=" + Uri.encode(value)
    }
    return if (value.startsWith("http://") || value.startsWith("https://")) value else "https://$value"
}


@Composable
private fun ExtensionsScreen(onOpen: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            "Developer-friendly, declarative extensions",
            color = Muted,
            fontSize = 14.sp
        )
        ExtensionRow(
            "Sample Web Shortcut",
            "Example HTTPS shortcut showing the extension entry model",
            "https://example.com",
            onOpen
        )
        ExtensionRow(
            "Android TV Developer Docs",
            "Reference material for developers building TV integrations",
            "https://developer.android.com/tv",
            onOpen
        )
        Surface(
            color = Panel,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, Color(0xFF27374D))
        ) {
            Column(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text("Build an extension", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "Add a JSON manifest with an id, name, version, description, HTTPS URL or installed Android package, declared capabilities and permissions. See extensions/README.md in the project.",
                    color = Muted,
                    fontSize = 13.sp
                )
                Text(
                    "Safety: v1 extensions are metadata and shortcuts only. The launcher does not download or execute arbitrary code.",
                    color = Muted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun ExtensionRow(
    title: String,
    description: String,
    url: String,
    onOpen: (String) -> Unit
) {
    Surface(
        onClick = { onOpen(url) },
        modifier = Modifier.fillMaxWidth().heightIn(min = 76.dp),
        shape = RoundedCornerShape(15.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color(0xFF27374D))
    ) {
        Row(
            Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier.size(42.dp).background(Panel2, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Extension, null, tint = Accent, modifier = Modifier.size(23.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(description, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.OpenInBrowser, null, tint = Accent)
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsRow("Startup", "Open StreamDeck TV to the home screen")
        SettingsRow("Browser", "Loaded only when opened to reduce memory use")
        SettingsRow("Privacy", "Browsing stays on this device in this prototype")
        SettingsRow("Streaming", "Playback is handled by official installed apps")
    }
}

@Composable
private fun SettingsRow(title: String, subtitle: String) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0xFF27374D))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(subtitle, color = Muted, fontSize = 13.sp)
        }
    }
}

private fun launchApp(context: Context, app: StreamApp) {
    val pm = context.packageManager
    for (packageName in app.packageCandidates) {
        val intent = pm.getLeanbackLaunchIntentForPackage(packageName)
            ?: pm.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            try {
                context.startActivity(intent)
                return
            } catch (_: ActivityNotFoundException) { }
        }
    }
    val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(app.name)))
    try {
        context.startActivity(market)
    } catch (_: ActivityNotFoundException) {
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(app.name) + "&c=apps"))
        context.startActivity(web)
    }
}
